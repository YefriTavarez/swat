Flexible Content, Gallery and Options Page are paid addons for the Advanced Custom Fields plugin (advancedcustomfields.com).
You can only use them within a purchased version of the Car Dealer plugin. Do not use them in your own projects.

Please buy the addons from the developers website: http://advancedcustomfields.com